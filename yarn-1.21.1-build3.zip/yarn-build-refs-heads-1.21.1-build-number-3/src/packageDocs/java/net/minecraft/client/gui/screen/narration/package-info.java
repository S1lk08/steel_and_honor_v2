/*
 * This file is free for everyone to use under the Creative Commons Zero license.
 */

/**
 * Contains the screen narrator for building
 * narration messages.
 */
package net.minecraft.client.gui.screen.narration;
