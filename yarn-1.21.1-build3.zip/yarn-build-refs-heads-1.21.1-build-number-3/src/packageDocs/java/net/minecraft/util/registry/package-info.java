/*
 * This file is free for everyone to use under the Creative Commons Zero license.
 */

/**
 * Contains the registry, used to register various in-game components, and related classes.
 *
 * @see Registry
 */
package net.minecraft.util.registry;
