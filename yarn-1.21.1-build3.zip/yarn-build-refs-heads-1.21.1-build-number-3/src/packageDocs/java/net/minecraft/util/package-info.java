/*
 * This file is free for everyone to use under the Creative Commons Zero license.
 */

/**
 * Contains utility method classes, various enums, serialization helpers, and
 * miscellaneous classes. {@link net.minecraft.util.Util} contains most of
 * the utility methods.
 */
package net.minecraft.util;
